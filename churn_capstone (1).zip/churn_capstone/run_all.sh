#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
mkdir -p data models outputs
python3 01_generate_data.py
python3 02_clean_eda_model.py
python3 03_predict.py
